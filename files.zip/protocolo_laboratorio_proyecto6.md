# Protocolo de laboratorio — Proyecto 6 (Monitor Inalámbrico Psiquiátrico)
### Sesión de integración incremental · ESP32 + MAX30102 + MPU6050 + DS18B20 + RC522

> Imprimir y llevar. Rellenar las casillas a mano durante la sesión: las mediciones
> que anoten aquí son insumo directo para la sección "Especificaciones técnicas"
> del informe.

---

## Antes de salir de casa

- [ ] Firmware de las 5 etapas ya **compilado sin errores** (Arduino IDE, board ESP32 seleccionada)
- [ ] Repositorio clonado en el notebook que llevarán al lab
- [ ] Multímetro disponible (propio o del lab — confirmar antes)
- [ ] Cables Dupont cortos y de colores por función:
      rojo = 3V3 · negro = GND · amarillo = SCL · verde = SDA · azul = datos
- [ ] Este protocolo impreso

---

## Mapa de pines acordado (fijarlo ANTES de conectar)

| Bus | Señal | GPIO ESP32 | Nota |
|---|---|---|---|
| I²C | SDA | 21 | compartido MAX30102 + MPU6050 |
| I²C | SCL | 22 | compartido |
| 1-Wire | DATA | 4 | pull-up 4.7 kΩ obligatorio a 3V3 |
| SPI (VSPI) | SCK | 18 | RC522 |
| SPI | MISO | 19 | RC522 |
| SPI | MOSI | 23 | RC522 |
| SPI | SS / SDA | 5 | RC522 |
| SPI | RST | 27 | RC522 (evitar 2, 12, 15: son strapping pins) |

**Direcciones esperadas:** MAX30102 = 0x57 · MPU6050 = 0x68 (0x69 si AD0 a VCC)

**Tensiones:** todo el bus lógico a 3.3 V. El RC522 opera a 2.5–3.3 V —
no alimentarlo a 5 V. El módulo MAX30102 suele traer regulador, pero
verificar la serigrafía de la placa concreta antes de conectar VIN.

---

## BLOQUE 0 — Integridad eléctrica (10 min, SIN firmware cargado)

ESP32 alimentada solo por USB, módulos aún desconectados del bus.

| # | Medición | Esperado | Medido | OK |
|---|---|---|---|---|
| 1 | 3V3 ↔ GND en la ESP32 | 3.2 – 3.3 V | ______ | ☐ |
| 2 | Continuidad GND ESP32 ↔ GND de cada módulo | < 1 Ω | ______ | ☐ |
| 3 | VIN de cada módulo ↔ GND (ya conectado) | ≈ 3.3 V | ______ | ☐ |
| 4 | SDA ↔ GND, bus en reposo | ≈ 3.3 V | ______ | ☐ |
| 5 | SCL ↔ GND, bus en reposo | ≈ 3.3 V | ______ | ☐ |
| 6 | **Sin alimentar:** R entre SDA y 3V3 | anotar | ______ | ☐ |
| 7 | **Sin alimentar:** R entre SCL y 3V3 | anotar | ______ | ☐ |

**Interpretación de 6 y 7:** si miden un valor finito (típicamente 2–10 kΩ),
los módulos **ya traen pull-ups en placa**. En ese caso NO agregar las 4.7 kΩ
externas sin recalcular: tres resistencias en paralelo bajan demasiado la
resistencia equivalente y aumentan la corriente de sink. Anotar el valor
medido y el cálculo en el informe.

**Criterio de avance:** si 4 o 5 dan ~0 V, hay corto o falta pull-up.
NO cargar firmware hasta resolverlo.

---

## BLOQUE 1 — MAX30102 solo (20 min)

Solo el MAX30102 en el bus. Cargar `etapa1_escaner_i2c`.

- [ ] Aparece `0x57` en el escaneo
- [ ] `PART_ID` leído: `0x______` (esperado 0x15 — verificar contra datasheet)
- [ ] Escaneo estable durante 10 ciclos seguidos (sin apariciones intermitentes)

**Si no aparece nada:** revisar en este orden → alimentación del módulo →
GND común → SDA/SCL invertidos → cable suelto. NO tocar el código todavía.

**Si aparece de forma intermitente:** problema de contacto o de pull-up,
no de software.

➜ **COMMIT:** `etapa1: MAX30102 detectado en 0x57, PART_ID verificado`

---

## BLOQUE 2 — Agregar MPU6050 al mismo bus (15 min)

- [ ] El escáner reporta **ambas** direcciones: `0x57` y `0x68`
- [ ] El MAX30102 sigue respondiendo (no basta con que aparezca el nuevo)
- [ ] Lectura cruda del acelerómetro con valores que cambian al mover la placa

**Punto de defensa:** poder explicar por qué dos dispositivos comparten
SDA/SCL sin conflicto (direcciones distintas + salidas open-drain).

➜ **COMMIT:** `etapa2: bus I2C compartido MAX30102 + MPU6050`

---

## BLOQUE 3 — DS18B20 en GPIO 4 (15 min)

- [ ] Pull-up de 4.7 kΩ instalada entre DATA y 3V3 (medir que esté)
- [ ] Alimentación normal, NO parásita
- [ ] ROM code del sensor leído y anotado: `________________`
- [ ] Temperatura coherente con el ambiente (~20 °C, no 85 °C ni -127 °C)

**85.0 °C** = valor de reset, la conversión no terminó → problema de
temporización o alimentación.
**-127 °C** = sensor no responde → cableado o pull-up.

➜ **COMMIT:** `etapa3: DS18B20 operativo en bus 1-Wire`

---

## BLOQUE 4 — RC522 por SPI (20 min)

- [ ] Alimentación a 3.3 V (verificar antes de energizar)
- [ ] `PCD_DumpVersionToSerial()` devuelve una versión válida (no 0x00 ni 0xFF)
- [ ] UID de un tag leído y anotado: `________________`
- [ ] UID de un segundo tag anotado: `________________`
- [ ] **Los tres sensores anteriores siguen leyendo mientras el RFID opera**

La última casilla es la que evalúa la rúbrica: "el proceso bloquea la
lectura de los demás sensores" es el criterio de puntaje 1.

➜ **COMMIT:** `etapa4: RC522 lee UID sin degradar la adquisición`

---

## BLOQUE 5 — Adquisición continua (15 min)

Cargar `etapa5_integracion` y dejar corriendo **10 minutos sin tocar nada**.

- [ ] Salida diagnóstica por consola con estado individual por módulo
- [ ] Sin reinicios de la ESP32 en 10 minutos
- [ ] Sin congelamiento ni tramas perdidas visibles
- [ ] Desconectar un sensor en caliente → el resto sigue funcionando y el
      módulo desconectado reporta ERROR (esto es una pregunta de defensa)

Formato de salida objetivo:

```
[t=001234 ms] MAX30102: OK  IR=12345   | MPU6050: OK  ax=0.02 g
              DS18B20 : OK  T=21.4 C   | RFID   : OK  ultimo=A3B21C04
```

➜ **COMMIT:** `etapa5: adquisicion simultanea estable 10 min`

---

## Evidencia a capturar antes de irse del lab

- [ ] **Foto en alta resolución del cableado**, ordenado, con buena luz
      (la rúbrica evalúa explícitamente la estética del cableado)
- [ ] Foto de detalle de la protoboard mostrando las pull-ups
- [ ] **Video de 30–60 s** de la consola con los cuatro módulos leyendo
- [ ] Captura de pantalla del monitor serie para el informe
- [ ] Video corto del RFID discriminando tag válido / inválido
- [ ] Esta hoja rellenada con las mediciones

---

## Plan B si algo no funciona

No improvisar rediseños. Prioridad de rescate, en este orden:

1. Que **los tres sensores base** lean simultáneamente (fila de mayor peso)
2. Que el diagnóstico reporte correctamente el módulo que falla
3. Que el cableado esté ordenado y fotografiado
4. RFID

Un sensor caído + diagnóstico que lo detecta y lo reporta se defiende
técnicamente mucho mejor que un firmware que se cuelga en silencio.

---

## Las cinco preguntas de la defensa (ensayar antes)

1. ¿Qué buses están utilizando y por qué esos?
2. ¿Por qué el MAX30102 y el MPU6050 pueden compartir el bus I²C?
3. ¿Qué ocurre en el software si un sensor desaparece?
4. ¿Cómo distinguen una medición válida de un error?
5. ¿Qué parte del firmware deberá seguir funcionando cuando agreguen Wi-Fi?

Que cada integrante pueda responder al menos dos. La rúbrica de IA penaliza
"estructuras que los alumnos no saben explicar".
